function data=DatosTarea3(dni,caso)

%data=DatosTarea3(dni,caso)
%
% dni:  dni del alumno (sin letra, numero: 123456)
% caso: caso del ejercicio (numero entre 1-4)
% data: vector con las muestradas generadas
%
% Llamar a la funci�n siempre con los dos par�metros de entrada y con tantos 
% parametros de salida como sean necesarios, ordenados alfabeticamente. 
%
% Por ejemplo, para el caso 2: data=DatosTarea3(12345,2)

dnis=num2str(dni);
ldni=length(dnis);
N=10000;

switch(caso)
    case 2
        a=-2*str2num(dnis(end))-1;
        b=str2num(dnis(end-1))+2;
        rand('seed',dni);
        data=a+(b-a)*rand(N,1);
    case 1,
        c=2*(mod(str2num(dnis(end)),3)+1);
        data=randi(c,N,1);       
    case 3,
        randn('seed',dni);
        m=str2num(dnis(end-1:end))+5; 
        c=mod(str2num(dnis(end-2)),2)+1;
        data1=m+c*randn(N/2,1);
        m=-str2num(dnis(end-4))-10; 
        c=mod(str2num(dnis(end-4)),2)+2;
        data2=m+c*randn(N/2,1);
        data(1:2:N-1)=data1;
        data(2:2:N)=data2; 
        data=data(:);  
        p = randperm(N);
        data=data(p);
     case 4,
        signo=mod(str2num(dnis(end-3)),2);
        m=str2num(dnis(end-1:end)); 
        if signo
            m=-m;
        end
        c=str2num(dnis(end-2))+1;
        randn('seed',dni);
        data=m+c*randn(N,1); 
        
      
    otherwise,
        error('Opcion no valida');


end



