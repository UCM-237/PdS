function [varargout]=DatosTarea1(dni,caso)

%[a,b,c,...]=DatosTarea1(dni,caso)
%
% dni:  dni del alumno (sin letra, numero: por ejemplo 123456)
% caso: caso del ejercicio (numero entre 1-6)
% a,b,c ...: parametros propios de cada funci�n
%
% Llamar a la funci�n siempre con los dos par�metros de entrada y con tantos 
% parametros de salida como sean necesarios, ordenados alfabeticamente. 
%
% Por ejemplo, para el caso 2: [a,b,c,d,e]=DatosTarea1(12345,2)


dnis=num2str(dni);
ldni=length(dnis);
switch(caso)
    case 1
        varargout{1}=mod(str2num(dnis(end-1)),4)+2;
    case 2,
        aux=ones(5,1);
        lm=min(5,ldni);
        for i=1:lm aux(i)=1+str2num(dnis(end+1-i));end;
        aux=aux/sum(aux);
        varargout=mat2cell(aux,[1 1 1 1 1],1);
    case 3,
        a=str2num(dnis(end-1))-str2num(dnis(end));
        b=a+str2num(dnis(end-2))+2;
        varargout{1}=a;
        varargout{2}=b;
    case 4,  
        signo=mod(str2num(dnis(end)),2);
        a=str2num(dnis(end-3:end-2));
        if ~signo
            a=-a;
        end
        b=mod(str2num(dnis(end-1)),3)+1;
        varargout{1}=a;
        varargout{2}=b;
    case 5,
        a=1+str2num(dnis(end-1));
        b=mod(str2num(dnis(end)),5)+1;
        varargout{1}=a;
        varargout{2}=b*0.5;         
    case 6,
        a=str2num(dnis(end));
        b=str2num(dnis(end-1))+a+1;
        c=str2num(dnis(end-2))+2*b;
        d=(mod(str2num(dnis(end-3)),3)+2)/2;       
        p1=(2+mod(str2num(dnis(end-4)),3))/5;
        p2=1-p1;    
        varargout{1}=p1;      
        varargout{2}=p2;
        varargout{3}=a;
        varargout{4}=b;         
        varargout{5}=c;
        varargout{6}=d;
    otherwise,
        error('Opcion no valida');
end